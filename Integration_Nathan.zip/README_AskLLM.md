# Ask LLM Background Enhancer

PaperQA项目中的Ask LLM模块实现，负责生成问题的先验背景知识。

## 功能概述

Ask LLM Background Enhancer是PaperQA系统的核心组件之一，实现了**先验推理**机制：

- 🧠 **背景知识生成**: 在检索外部信息前，先利用LLM的预训练知识
- 🎯 **智能模板选择**: 根据问题类型自动选择最适合的提示词模板
- ⚡ **高效缓存机制**: 避免重复计算，提高响应速度
- 🔧 **参数优化**: 自动调优温度和token长度参数
- 🔗 **模块化接口**: 与其他PaperQA组件无缝集成

## 核心特性

### 1. 多模板支持
- **Default**: 通用科学问题
- **Biomedical**: 生物医学专业问题
- **Technical**: 技术方法问题
- **Minimal**: 简洁回答模式

### 2. 智能缓存
- 基于问题内容的MD5哈希缓存
- 可配置的TTL（生存时间）
- 自动清理过期缓存

### 3. 参数优化
- 自动测试不同温度设置
- Token长度优化
- 置信度评分机制

## 安装依赖

```bash
pip install openai python-dotenv
```

## 快速开始

### 1. 基本使用

```python
from ask_llm_background_enhancer import AskLLMBackgroundEnhancer, AskLLMConfig

# 创建配置
config = AskLLMConfig(
    model="gpt-4",
    temperature=0.5,
    max_tokens=150,
    cache_enabled=True
)

# 初始化
enhancer = AskLLMBackgroundEnhancer(config)

# 生成背景知识
question = "What is the role of CD33 in acute myeloid leukemia?"
response = enhancer.generate_background(question)

print(f"背景知识: {response.background_text}")
print(f"置信度: {response.confidence_score:.2f}")
```

### 2. 批量处理

```python
questions = [
    "What is CRISPR-Cas9?",
    "How do cancer cells develop resistance?",
    "What is machine learning?"
]

responses = enhancer.batch_generate_background(questions)
for response in responses:
    print(f"问题: {response.question}")
    print(f"背景: {response.background_text}")
    print(f"置信度: {response.confidence_score:.2f}")
    print()
```

### 3. 参数优化

```python
test_questions = [
    "What is gene therapy?",
    "How do vaccines work?",
    "What is protein folding?"
]

best_params = enhancer.optimize_parameters(test_questions)
print(f"最优参数: {best_params}")
```

## 配置选项

### AskLLMConfig参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `model` | str | "gpt-4" | 使用的LLM模型 |
| `temperature` | float | 0.5 | 生成温度 |
| `max_tokens` | int | 150 | 最大token数 |
| `cache_enabled` | bool | True | 是否启用缓存 |
| `cache_ttl_hours` | int | 24 | 缓存生存时间（小时） |
| `retry_attempts` | int | 3 | 重试次数 |
| `timeout_seconds` | int | 30 | 超时时间 |

## API参考

### AskLLMBackgroundEnhancer类

#### 主要方法

- `generate_background(question, template_type=None)`: 生成单个问题的背景知识
- `batch_generate_background(questions)`: 批量生成背景知识
- `optimize_parameters(test_questions)`: 参数优化
- `get_cache_stats()`: 获取缓存统计
- `clear_cache()`: 清空缓存
- `export_backgrounds(output_file)`: 导出背景知识

#### 内部方法

- `_select_prompt_template(question)`: 选择提示词模板
- `_generate_cache_key(question, template_type)`: 生成缓存键
- `_calculate_confidence_score(background_text, question)`: 计算置信度

### BackgroundResponse数据结构

```python
@dataclass
class BackgroundResponse:
    question: str                    # 原始问题
    background_text: str            # 生成的背景知识
    confidence_score: float         # 置信度 (0-1)
    generated_at: datetime          # 生成时间
    model_used: str                 # 使用的模型
    tokens_used: int                # 使用的token数
    temperature: float              # 使用的温度
```

## 与其他模块的集成

### 1. 向Answer LLM传递背景知识

```python
from shared_interfaces import SharedInterfaces, BackgroundKnowledge

# 创建背景知识对象
background = BackgroundKnowledge(
    question_id="q001",
    background_text="CD33 is a cell surface receptor...",
    confidence_score=0.8,
    generated_at=datetime.now(),
    model_used="gpt-4",
    tokens_used=45,
    template_type="biomedical"
)

# 转换为Answer LLM格式
answer_format = SharedInterfaces.ask_llm_to_answer_llm(background)
```

### 2. 任务队列集成
### 3. 一键端到端运行（与Search/Gather/Answer对接）

已提供最小流水线：

```
py -m paperqa.main --q "What is the role of CD33 in AML?"
```

要求根目录存在以下模块（或你们已有实现）：
- `tool_search.py` 暴露 `run_tool(input_dict)->dict`
- `tool_gather.py` 暴露 `run_tool(input_dict)->dict`
- `tool_answer.py` 暴露 `run_tool(input_dict)->dict`

流水线编排位于 `paperqa/pipeline.py`，Ask工具为 `paperqa/tools/tool_ask.py`。


```python
from shared_interfaces import TaskRequest, ModuleType, Question

# 创建任务请求
task = TaskRequest(
    task_id="task001",
    module_type=ModuleType.ASK_LLM,
    question=Question(id="q001", text="What is DNA?"),
    input_data={"template_type": "biomedical"}
)

# 转换为队列消息
queue_message = SharedInterfaces.create_task_queue_message(task)
```

## 测试

运行测试套件：

```bash
python test_ask_llm.py
```

测试包括：
- ✅ 基本功能测试
- ✅ 模板选择测试
- ✅ 缓存功能测试
- ✅ 批量处理测试
- ✅ 参数优化测试
- ✅ 共享接口测试
- ✅ 错误处理测试
- ✅ 性能测试

## 性能优化建议

### 1. 缓存策略
- 启用缓存以减少API调用
- 根据使用模式调整TTL
- 定期清理过期缓存

### 2. 参数调优
- 使用`optimize_parameters()`找到最佳设置
- 根据问题类型调整温度
- 平衡token使用和响应质量

### 3. 批量处理
- 使用`batch_generate_background()`处理多个问题
- 添加适当的延迟避免API限制

## 故障排除

### 常见问题

1. **API密钥错误**
   ```
   解决方案: 设置OPENAI_API_KEY环境变量
   ```

2. **缓存问题**
   ```
   解决方案: 调用clear_cache()或检查cache目录权限
   ```

3. **超时错误**
   ```
   解决方案: 增加timeout_seconds或检查网络连接
   ```

### 调试模式

启用详细日志：

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 贡献指南

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 运行测试
5. 提交Pull Request

## 许可证

MIT License

## 联系方式

- 开发者: Nathan (C - Ask LLM Developer)
- 项目: PaperQA复现项目
- 邮箱: [your-email@example.com]

---

**注意**: 这是PaperQA项目的C模块实现，需要与其他模块（A、B、D）配合使用才能实现完整的PaperQA系统。




