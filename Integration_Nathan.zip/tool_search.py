# paperqa/tools/tool_search.py
import os
import arxiv
import requests
import fitz
import asyncio
from typing import List
from paperqa.schemas import SearchHit, Chunk
from settings import Settings as RootSettings
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import nltk
from nltk.corpus import wordnet as wn

# make sure cache folder exists
os.makedirs("paperqa/data/cache", exist_ok=True)

# settings mapping (read from root Settings)
CHUNK_SIZE = getattr(RootSettings, "CHUNK_SIZE", 1800)
CHUNK_OVERLAP = getattr(RootSettings, "CHUNK_OVERLAP", 0.1)


class SearchTool:
    def __init__(self, scholar_client, arxiv_client, pubmed_client, parser, embedder, indexer, cache):
        self.scholar = scholar_client
        self.arxiv = arxiv_client
        self.pubmed = pubmed_client
        self.parser = parser
        self.embedder = SentenceTransformer("BAAI/bge-base-en")  # ✅ load embedding model
        self.index_dim = 768  # bge-base-en outputs 768-dim embeddings
        self.indexer = faiss.IndexFlatL2(self.index_dim)  # ✅ simple FAISS index (L2 similarity)
        self.cache = cache

    async def search(self, question: str, year_hint: str | None = None) -> List[SearchHit]:
        variants = self._expand_queries(question, year_hint)
        return await self._fanout_discovery(variants)

    def expand_query_terms(self, question: str, max_terms: int = 5) -> list:
        """
        Expand key terms in the user's query using WordNet synonyms.
        - Extracts meaningful words from the question.
        - For each word, finds up to 2 close synonyms.
        - Returns a list of unique additional terms for reformulation.
        """
        # Ensure NLTK wordnet is available
        try:
            _ = wn.synsets("test")
        except LookupError:
            try:
                nltk.download("wordnet", quiet=True)
            except Exception:
                return []

        words = [w for w in question.lower().split() if w.isalpha()]
        related = set()

        for w in words:
            for syn in wn.synsets(w):
                for lemma in syn.lemmas()[:2]:  # top 2 synonyms per word
                    name = lemma.name().replace("_", " ")
                    if name != w:
                        related.add(name)

        # return only the top few diverse related terms
        return list(related)[:max_terms]

    async def smart_search(
        self,
        question: str,
        year_hint: str | None = None,
        min_hits: int = 3,
        max_rounds: int = 3
    ):
        """
        🧠 Self-evaluating smart search loop (with WordNet expansion).
        - Expands query terms dynamically using WordNet synonyms.
        - Reformulates queries each round if too few papers are found.
        - Deduplicates results by paper_id.
        - Returns all unique SearchHit objects (silent version).
        """
        all_hits = []
        seen_ids = set()

        # Step 1: Generate initial reformulations using WordNet
        reformulations = self.expand_query_terms(question)
        if not reformulations:
            reformulations = ["review", "overview", "case study"]  # fallback

        # Step 2: Perform multiple rounds of search
        for attempt in range(max_rounds):
            # build a reformulated query
            if attempt < len(reformulations):
                query_variant = f"{question} {reformulations[attempt]}"
            else:
                query_variant = question  # fallback to original

            # perform search
            hits = await self.search(query_variant, year_hint)

            # keep only new hits
            new_hits = [h for h in hits if h.paper_id not in seen_ids]
            for h in new_hits:
                seen_ids.add(h.paper_id)
                all_hits.append(h)

            # stop condition
            if len(all_hits) >= min_hits:
                break

        return all_hits


    async def ingest(self, hits: List[SearchHit]) -> List[Chunk]:
        all_chunks: List[Chunk] = []
        for hit in hits[:5]:  # limit 5 PDFs for testing
            pdf_url = hit.urls.get("pdf")
            if not pdf_url:
                continue

            safe_id = (
                hit.paper_id.replace("http://", "")
                .replace("https://", "")
                .replace("/", "_")
                .replace(":", "_")
            )
            pdf_path = self._download_pdf(pdf_url, safe_id)
            if not pdf_path:
                continue

            text = self._pdf_to_text(pdf_path)
            if not isinstance(text, str) or not text.strip():
                continue

            chunks = self._make_chunks(hit.paper_id, text)
            all_chunks.extend(chunks)

        # ✅ embed chunks and index them
        texts = [chunk.text for chunk in all_chunks]
        if texts:
            embeddings = self.embedder.encode(texts, convert_to_numpy=True)

            # Print a preview vector
            print("\n[EMBEDDING PREVIEW]")
            print(embeddings[0][:10])  # show first 10 numbers of first embedding

            # ✅ add to FAISS index
            self.indexer.add(embeddings)

            self.save_faiss_index()


        return all_chunks

    def _expand_queries(self, q: str, years: str | None) -> List[str]:
        return [q if not years else f"{q} {years}"]

    async def _fanout_discovery(self, queries: List[str]) -> List[SearchHit]:
        results: List[SearchHit] = []
        for query in queries:
            search = arxiv.Search(
                query=query,
                max_results=5,
                sort_by=arxiv.SortCriterion.Relevance
            )
            for result in search.results():
                results.append(
                    SearchHit(
                        source="arxiv",
                        paper_id=result.entry_id,
                        title=result.title,
                        year=result.published.year if result.published else None,
                        urls={"pdf": result.pdf_url},
                    )
                )
        return results

    def _download_pdf(self, url: str, paper_id: str) -> str:
        pdf_path = os.path.join("paperqa", "data", "cache", f"{paper_id}.pdf")
        if os.path.exists(pdf_path):
            return pdf_path
        try:
            response = requests.get(url, timeout=15)
            with open(pdf_path, "wb") as f:
                f.write(response.content)
            return pdf_path
        except:
            return ""

    def _pdf_to_text(self, pdf_path: str) -> str:
        try:
            with fitz.open(pdf_path) as doc:
                return "".join(page.get_text("text") for page in doc)
        except:
            return ""

    def _make_chunks(self, paper_id: str, text: str) -> List[Chunk]:
        if not text:
            return []
        chunks = []
        start = 0
        idx = 0
        # 处理 CHUNK_OVERLAP：如果是浮点数（比例），则转换为字符数
        if isinstance(CHUNK_OVERLAP, float):
            overlap_chars = int(CHUNK_SIZE * CHUNK_OVERLAP)
        else:
            overlap_chars = int(CHUNK_OVERLAP)
        
        while start < len(text):
            end = min(start + CHUNK_SIZE, len(text))  # 确保不超过文本长度
            chunks.append(
                Chunk(
                    paper_id=paper_id,
                    chunk_id=f"{paper_id}_chunk_{idx}",
                    start=start,
                    end=end,
                    text=text[start:end],
                )
            )
            idx += 1
            # 计算下一个 chunk 的起始位置（考虑重叠）
            start = end - overlap_chars
            # 确保 start 不会变成负数
            if start < 0:
                start = end  # 如果没有重叠空间，从下一个位置开始
            # 防止无限循环：如果下一个起始位置没有前进，则停止
            if start >= len(text) or start <= chunks[-1].start:
                break
        return chunks

    def save_faiss_index(self, path="paperqa/data/faiss.index"):
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        faiss.write_index(self.indexer, path)
        print(f"[FAISS] Index saved to {path}")

    def load_faiss_index(self, path="paperqa/data/faiss.index"):
        if os.path.exists(path):
            self.indexer = faiss.read_index(path)
            print(f"[FAISS] Index loaded from {path}")
        else:
            print(f"[FAISS] No existing index found at {path}")

    def inspect_faiss(self, k: int = 3):
        """Simple FAISS self-test: loads index, runs a dummy search."""
        try:
            # Load saved index
            self.load_faiss_index()

            print("\n[FAISS] ✅ Index status")
            print(f" - Stored vectors: {self.indexer.ntotal}")
            print(f" - Vector dimension: {self.indexer.d}")

            if self.indexer.ntotal == 0:
                print(" - ⚠️ Index is empty. Run ingest() first.")
                return

            # Create a random query to test search
            import numpy as np
            dummy_query = np.random.random((1, self.indexer.d)).astype("float32")
            distances, ids = self.indexer.search(dummy_query, k)

            print(f" - 🔎 Test query returned {len(ids[0])} nearest neighbors")
            print(f" - Vector IDs: {ids[0]}")
        except Exception as e:
            print(f"[FAISS] ❌ Error inspecting FAISS index: {e}")

if __name__ == "__main__":
    import json
    import random
    import nltk

    nltk.download("wordnet", quiet=True)

    async def test_litqa():
        tool = SearchTool(None, None, None, None, None, None, None)

        litqa_path = "/Users/Lenovo1/Desktop/RAG/paperqa/litqa-v0.jsonl"
        with open(litqa_path, "r") as f:
            samples = [json.loads(line) for line in f if line.strip()]
        random.seed(123)
        sample = random.choice(samples)
        question = sample["question"]

        
        # 🧩 Show related terms used by SmartSearch
        related = tool.expand_query_terms(question)
        print(f"\n🧠 WordNet expansions used for SmartSearch:")
        print(f"   {related if related else '(no expansion found)'}")

        # ✅ Run SmartSearch
        hits = await tool.smart_search(question)
        print(f"\n🧪 Testing LitQA Question:\n{question}")
        # 🔍 Print all retrieved papers
        print(f"\n📚 Papers retrieved ({len(hits)} total):")
        for i, h in enumerate(hits):
            print(f"  {i+1}. {h.title} ({h.year}) | {h.paper_id}")

        # 📄 Now extract paper chunks
        chunks = await tool.ingest(hits)
        print(f"\n📄 PDF Text Chunks Generated: {len(chunks)}")
        if chunks:
            print(f"Example chunk from first paper:\n{chunks[1].text[:300]}...")  # preview first 300 chars

        # 🧮 Check FAISS index
        tool.inspect_faiss()

    asyncio.run(test_litqa())


# ---- Functional wrapper for pipeline integration ----
def run_tool(input_dict):
    """Run search+ingest for a question.

    Input:
      {"question": str, "year_hint": Optional[str]}
    Output dict:
      {
        "hits": [SearchHit as dict...],
        "chunks": [Chunk as dict...]
      }
    """
    from paperqa.schemas import SearchHit as SH, Chunk as CK
    import asyncio as _asyncio

    question = input_dict.get("question", "")
    year_hint = input_dict.get("year_hint")

    tool = SearchTool(None, None, None, None, None, None, None)

    async def _run():
        hits = await tool.smart_search(question, year_hint=year_hint)
        chunks = await tool.ingest(hits)
        return hits, chunks

    hits, chunks = _asyncio.run(_run())

    def _asdict_hit(h: SH):
        return {
            "source": h.source,
            "paper_id": h.paper_id,
            "title": h.title,
            "year": h.year,
            "urls": h.urls,
        }

    def _asdict_chunk(c: CK):
        return {
            "paper_id": c.paper_id,
            "chunk_id": c.chunk_id,
            "start": c.start,
            "end": c.end,
            "text": c.text,
            "embedding": c.embedding,
        }

    return {
        "hits": [_asdict_hit(h) for h in hits],
        "chunks": [_asdict_chunk(c) for c in chunks],
    }
