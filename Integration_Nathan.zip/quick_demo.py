"""
Ask LLM模块快速展示脚本
适合在会议中快速演示核心功能

Author: Nathan (C - Ask LLM Developer)
"""

import os
import time
from ask_llm_gemini import AskLLMBackgroundEnhancer, AskLLMConfig

def quick_demo():
    """快速演示"""
    print("Ask LLM模块快速演示")
    print("=" * 50)
    
    # 检查API
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("[ERROR] 请设置GEMINI_API_KEY")
        return
    
    # 初始化
    config = AskLLMConfig(model="gemini-2.0-flash", cache_enabled=True)
    enhancer = AskLLMBackgroundEnhancer(config, api_key)
    
    # 演示问题
    questions = [
        "What is the role of CD33 in acute myeloid leukemia?",
        "How does CRISPR-Cas9 gene editing work?",
        "What machine learning methods are used in drug discovery?"
    ]
    
    print(f"\n演示问题 ({len(questions)}个):")
    for i, q in enumerate(questions, 1):
        print(f"   {i}. {q}")
    
    print(f"\n开始处理...")
    
    total_start = time.time()
    for i, question in enumerate(questions, 1):
        print(f"\n--- 问题 {i} ---")
        print(f"问题: {question}")
        
        start_time = time.time()
        response = enhancer.generate_background(question)
        end_time = time.time()
        
        print(f"背景: {response.background_text[:100]}...")
        print(f"置信度: {response.confidence_score:.2f}")
        print(f"时间: {end_time - start_time:.2f}秒")
        print(f"Token: {response.tokens_used}")
    
    total_time = time.time() - total_start
    print(f"\n总处理时间: {total_time:.2f}秒")
    print(f"平均时间: {total_time/len(questions):.2f}秒/问题")
    
    # 缓存测试
    print(f"\n缓存测试:")
    test_question = "What is DNA?"
    
    # 第一次
    start_time = time.time()
    response1 = enhancer.generate_background(test_question)
    time1 = time.time() - start_time
    
    # 第二次（缓存）
    start_time = time.time()
    response2 = enhancer.generate_background(test_question)
    time2 = time.time() - start_time
    
    print(f"第一次: {time1:.3f}秒")
    print(f"第二次: {time2:.3f}秒")
    if time2 > 0:
        print(f"加速: {time1/time2:.1f}x")
    else:
        print("加速: 极快 (缓存)")
    
    print(f"\n演示完成!")

if __name__ == "__main__":
    quick_demo()
