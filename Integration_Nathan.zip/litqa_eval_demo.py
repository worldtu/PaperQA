"""
LitQA2 子集快速评测脚本
基于 Hugging Face 数据集 futurehouse/lab-bench 的 LitQA2 子集，
对 Ask LLM (Background Enhancer) 的 50 词背景生成进行示例评测。

Usage:
  py -m pip install -r requirements.txt
  $env:GEMINI_API_KEY="your-key"
  py litqa_eval_demo.py
"""

import os
import time
from datasets import load_dataset
from ask_llm_gemini import AskLLMBackgroundEnhancer, AskLLMConfig


def main():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("[ERROR] 未设置 GEMINI_API_KEY 环境变量")
        return

    # 初始化 Ask LLM（限制 50 词输出）
    config = AskLLMConfig(
        model="gemini-2.0-flash",
        temperature=0.5,
        max_tokens=150,
        max_words=50,
        cache_enabled=True,
    )
    enhancer = AskLLMBackgroundEnhancer(config, api_key)

    # 加载 LitQA2 子集（来自 LAB-Bench 数据集）
    # 参考: https://huggingface.co/datasets/futurehouse/lab-bench
    ds = load_dataset("futurehouse/lab-bench", "LitQA2")
    dataset = ds["train"]  # 公开子集

    print("LitQA2 示例评测 (前 5 条)")
    print("=" * 60)

    n = min(5, len(dataset))
    total_time = 0.0
    for i in range(n):
        example = dataset[i]
        question = example.get("question", "")
        ideal = example.get("ideal", "")  # 数据集中参考答案字段

        print(f"\n[{i+1}] 问题: {question[:200]}...")
        start = time.time()
        resp = enhancer.generate_background(question)
        elapsed = time.time() - start
        total_time += elapsed

        print(f"背景(<=50词): {resp.background_text}")
        print(f"置信度: {resp.confidence_score:.2f} | 时间: {elapsed:.2f}s")
        if ideal:
            print(f"参考答案(截断): {ideal[:200]}...")

    if n:
        print("\n统计:")
        print(f"平均响应时间: {total_time/n:.2f}s")


if __name__ == "__main__":
    main()



