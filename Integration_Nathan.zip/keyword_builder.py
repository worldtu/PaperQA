"""
LitQA2 关键词构建脚本
从 Hugging Face 数据集 futurehouse/lab-bench 的 LitQA2 子集抽取高频关键词，
生成两个JSON：data/keywords_biomedical.json、data/keywords_technical.json

用法:
  py -m pip install -r requirements.txt
  py keyword_builder.py
"""

import os
import json
from collections import Counter
from pathlib import Path
from datasets import load_dataset


STOPWORDS = {
    "the","a","an","of","and","or","to","in","on","for","with","by","from","at","as","is","are","was","were","be","been","being","that","this","these","those","it","its","their","his","her","we","you","they","i","do","does","did","can","could","may","might","should","would","will","than","into","over","under","between","among","about","across","per","each","within","without","such","using","use","via","based","using","into","across","vs","into","how","what","which","when","why","where"
}

# 种子词表（用于弱监督分类与过滤）
SEED_BIOMED = {
    "dna","rna","protein","gene","genetic","mrna","crispr","cas9","cell","cells","tumor","cancer","disease","therapy","therapeutic","clinical","patient","antibody","assay","knockout","knockdown","overexpression","mutation","pathway","metastasis","enzyme","receptor","ligand","sequence","sequencing","pcr","qpcr","western","elisa","microscopy","transfection","plasmid","vector","promoter","transcript","phenotype","genotype","immuno","flow","facs"
}

SEED_TECH = {
    "algorithm","model","method","technique","pipeline","workflow","protocol","procedure","analysis","measurement","quantification","normalization","benchmark","evaluation","dataset","statistical","regression","classification","clustering","neural","network","deep","learning","inference","optimization","implementation","deployment","integration"
}


def tokenize(text: str):
    text = (text or "").lower()
    tokens = []
    cur = []
    for ch in text:
        if ch.isalnum() or ch in ['-','+']:
            cur.append(ch)
        else:
            if cur:
                tokens.append(''.join(cur))
                cur = []
    if cur:
        tokens.append(''.join(cur))
    return [t for t in tokens if t and t not in STOPWORDS and not t.isdigit()]


def build_keywords(max_unigrams: int = 200):
    ds = load_dataset("futurehouse/lab-bench", "LitQA2")
    train = ds["train"]

    counter = Counter()
    for row in train:
        q = row.get("question", "")
        counter.update(tokenize(q))

    # 过滤过短/过长/杂项
    candidates = [w for w,_ in counter.most_common(2000) if 2 <= len(w) <= 30]

    bio, tech = [], []
    for w in candidates:
        if (w in SEED_BIOMED) or any(seed in w for seed in SEED_BIOMED):
            bio.append(w)
        elif (w in SEED_TECH) or any(seed in w for seed in SEED_TECH):
            tech.append(w)

    # 取前N个，避免过长
    bio = bio[:max_unigrams]
    tech = tech[:max_unigrams]

    out_dir = Path("data")
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "keywords_biomedical.json").write_text(json.dumps(bio, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "keywords_technical.json").write_text(json.dumps(tech, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"[OK] 关键词已生成: {len(bio)} biomedical, {len(tech)} technical")
    print(f"输出目录: {out_dir.resolve()}")


if __name__ == "__main__":
    build_keywords()



