"""
支持Gemini API的Ask LLM Background Enhancer
使用Google Gemini替代OpenAI API

Author: Nathan (C - Ask LLM Developer)
"""

import json
import hashlib
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import time
import pickle
from datetime import datetime, timedelta
import google.generativeai as genai

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class BackgroundResponse:
    """背景知识响应的数据结构"""
    question: str
    background_text: str
    confidence_score: float  # 0-1之间的置信度
    generated_at: datetime
    model_used: str
    tokens_used: int
    temperature: float

@dataclass
class AskLLMConfig:
    """Ask LLM的配置参数"""
    model: str = "gemini-2.0-flash"  # 使用更稳定的模型
    temperature: float = 0.5
    max_tokens: int = 150
    # 生成的背景文本最大词数（硬性上限）
    max_words: int = 50
    cache_enabled: bool = True
    cache_ttl_hours: int = 24
    retry_attempts: int = 3
    timeout_seconds: int = 30

class AskLLMBackgroundEnhancer:
    """
    Ask LLM Background Enhancer - 支持Gemini API
    
    核心功能：
    1. 生成问题的背景知识
    2. 缓存机制优化性能
    3. 参数调优和优化
    4. 与其他模块的接口对接
    """
    
    def __init__(self, config: AskLLMConfig, api_key: Optional[str] = None):
        self.config = config
        self.cache_dir = Path("cache/ask_llm")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._dyn_bio_keywords: Optional[List[str]] = None
        self._dyn_tech_keywords: Optional[List[str]] = None
        
        # 初始化Gemini
        if api_key:
            genai.configure(api_key=api_key)
        else:
            # 尝试从环境变量获取
            import os
            api_key = os.getenv("GEMINI_API_KEY")
            if api_key:
                genai.configure(api_key=api_key)
            else:
                logger.warning("未找到Gemini API密钥")
        
        self.model = genai.GenerativeModel(config.model)
        
        # 初始化提示词模板
        self.prompt_templates = self._initialize_prompt_templates()
        # 尝试加载动态关键词
        self._load_dynamic_keywords()
        
        logger.info(f"Ask LLM Background Enhancer initialized with model: {config.model}")
    
    def _initialize_prompt_templates(self) -> Dict[str, str]:
        """初始化不同的提示词模板"""
        return {
            "default": """Provide a brief background summary (40-50 words) about the topic in this question. Keep it factual and concise. Do not exceed 50 words.

Question: {question}

Background:""",
            
            "biomedical": """Provide a brief biological background (40-50 words). Focus on established scientific facts, key entities, and mechanisms. Do not exceed 50 words.

Question: {question}

Background:""",
            
            "technical": """Provide a brief technical background (40-50 words). Focus on methods, principles, and standard practice. Do not exceed 50 words.

Question: {question}

Background:""",
            
            "minimal": """Provide a very brief background (<=50 words) about the topic in this question. Focus only on established facts.

Question: {question}

Background:"""
        }
    
    def _load_dynamic_keywords(self) -> None:
        """从 data/ 目录加载由 LitQA2 构建的关键词，失败则保持为 None。"""
        try:
            bio_path = Path("data/keywords_biomedical.json")
            tech_path = Path("data/keywords_technical.json")
            if bio_path.exists():
                self._dyn_bio_keywords = json.loads(bio_path.read_text(encoding="utf-8"))
            if tech_path.exists():
                self._dyn_tech_keywords = json.loads(tech_path.read_text(encoding="utf-8"))
            if self._dyn_bio_keywords or self._dyn_tech_keywords:
                logger.info("Loaded dynamic keywords from data/ directory")
        except Exception as e:
            logger.warning(f"Failed to load dynamic keywords: {e}")
    
    def _generate_cache_key(self, question: str, template_type: str = "default") -> str:
        """生成缓存键"""
        content = f"{question}_{template_type}_{self.config.model}_{self.config.temperature}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _load_from_cache(self, cache_key: str) -> Optional[BackgroundResponse]:
        """从缓存加载背景响应"""
        if not self.config.cache_enabled:
            return None
            
        cache_file = self.cache_dir / f"{cache_key}.pkl"
        
        if not cache_file.exists():
            return None
            
        try:
            with open(cache_file, 'rb') as f:
                cached_data = pickle.load(f)
            
            # 检查缓存是否过期
            if datetime.now() - cached_data.generated_at > timedelta(hours=self.config.cache_ttl_hours):
                cache_file.unlink()  # 删除过期缓存
                return None
                
            logger.info(f"Loaded background from cache for question: {cached_data.question[:50]}...")
            return cached_data
            
        except Exception as e:
            logger.warning(f"Failed to load cache: {e}")
            return None
    
    def _save_to_cache(self, cache_key: str, response: BackgroundResponse):
        """保存背景响应到缓存"""
        if not self.config.cache_enabled:
            return
            
        try:
            cache_file = self.cache_dir / f"{cache_key}.pkl"
            with open(cache_file, 'wb') as f:
                pickle.dump(response, f)
            logger.info(f"Cached background response for key: {cache_key}")
        except Exception as e:
            logger.warning(f"Failed to save cache: {e}")
    
    def _select_prompt_template(self, question: str) -> str:
        """根据问题类型选择合适的提示词模板"""
        question_lower = question.lower()
        
        # 生物医学关键词
        biomedical_keywords = self._dyn_bio_keywords or ['protein', 'gene', 'cell', 'dna', 'rna', 'cancer', 'disease', 
                            'therapy', 'drug', 'clinical', 'patient', 'medical', 'biological']
        
        # 技术关键词
        technical_keywords = self._dyn_tech_keywords or ['method', 'technique', 'algorithm', 'model', 'analysis', 
                            'experiment', 'measurement', 'protocol', 'procedure']
        
        if any(keyword in question_lower for keyword in biomedical_keywords):
            return "biomedical"
        elif any(keyword in question_lower for keyword in technical_keywords):
            return "technical"
        else:
            return "default"
    
    def _call_gemini_api(self, prompt: str) -> Tuple[str, int]:
        """调用Gemini API获取响应"""
        for attempt in range(self.config.retry_attempts):
            try:
                # 配置生成参数
                generation_config = genai.types.GenerationConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                )
                
                response = self.model.generate_content(
                    prompt,
                    generation_config=generation_config
                )
                
                content = response.text.strip()
                # 估算token使用量（Gemini不直接提供）
                tokens_used = len(content.split()) + len(prompt.split())
                
                return content, tokens_used
                
            except Exception as e:
                logger.warning(f"Gemini API call attempt {attempt + 1} failed: {e}")
                if attempt < self.config.retry_attempts - 1:
                    time.sleep(2 ** attempt)  # 指数退避
                else:
                    raise e
    
    def _calculate_confidence_score(self, background_text: str, question: str) -> float:
        """计算背景知识的置信度分数"""
        if not background_text or background_text.lower().startswith("i don't know"):
            return 0.1
        
        # 简单的启发式置信度计算
        confidence = 0.5  # 基础分数
        
        # 基于长度的调整
        word_count = len(background_text.split())
        if word_count > 20:
            confidence += 0.2
        elif word_count < 10:
            confidence -= 0.2
        
        # 基于专业术语的调整
        technical_terms = ['protein', 'gene', 'cell', 'molecule', 'mechanism', 'process', 'function']
        if any(term in background_text.lower() for term in technical_terms):
            confidence += 0.1
        
        # 基于不确定性的调整
        uncertainty_words = ['might', 'could', 'possibly', 'perhaps', 'maybe', 'unclear']
        if any(word in background_text.lower() for word in uncertainty_words):
            confidence -= 0.1
        
        return max(0.0, min(1.0, confidence))
    
    @staticmethod
    def _truncate_to_words(text: str, max_words: int) -> str:
        """将文本截断到指定的最大词数。"""
        words = text.split()
        if len(words) <= max_words:
            return text
        return " ".join(words[:max_words])
    
    def generate_background(self, question: str, template_type: Optional[str] = None) -> BackgroundResponse:
        """
        为主要功能：生成问题的背景知识
        
        Args:
            question: 用户问题
            template_type: 提示词模板类型，如果为None则自动选择
            
        Returns:
            BackgroundResponse: 包含背景知识的响应对象
        """
        # 检查缓存
        if template_type is None:
            template_type = self._select_prompt_template(question)
        
        cache_key = self._generate_cache_key(question, template_type)
        cached_response = self._load_from_cache(cache_key)
        
        if cached_response:
            return cached_response
        
        # 生成新的背景知识
        logger.info(f"Generating background for question: {question[:50]}...")
        
        try:
            # 构建提示词
            prompt_template = self.prompt_templates[template_type]
            prompt = prompt_template.format(question=question)
            
            # 调用Gemini API
            background_text, tokens_used = self._call_gemini_api(prompt)
            # 确保输出不超过指定词数
            background_text = self._truncate_to_words(background_text, self.config.max_words)
            
            # 计算置信度
            confidence_score = self._calculate_confidence_score(background_text, question)
            
            # 创建响应对象
            response = BackgroundResponse(
                question=question,
                background_text=background_text,
                confidence_score=confidence_score,
                generated_at=datetime.now(),
                model_used=self.config.model,
                tokens_used=tokens_used,
                temperature=self.config.temperature
            )
            
            # 保存到缓存
            self._save_to_cache(cache_key, response)
            
            logger.info(f"Generated background with confidence: {confidence_score:.2f}")
            return response
            
        except Exception as e:
            logger.error(f"Failed to generate background: {e}")
            # 返回默认响应
            return BackgroundResponse(
                question=question,
                background_text="I don't have sufficient background knowledge about this topic.",
                confidence_score=0.1,
                generated_at=datetime.now(),
                model_used=self.config.model,
                tokens_used=0,
                temperature=self.config.temperature
            )
    
    def batch_generate_background(self, questions: List[str]) -> List[BackgroundResponse]:
        """批量生成背景知识"""
        responses = []
        
        for i, question in enumerate(questions):
            logger.info(f"Processing question {i+1}/{len(questions)}")
            response = self.generate_background(question)
            responses.append(response)
            
            # 避免API限制
            time.sleep(0.5)
        
        return responses
    
    def optimize_parameters(self, test_questions: List[str]) -> Dict[str, float]:
        """
        参数优化：测试不同的温度和token长度设置
        
        Args:
            test_questions: 测试问题列表
            
        Returns:
            最优参数配置
        """
        logger.info("Starting parameter optimization...")
        
        # 测试不同的参数组合
        temperature_options = [0.2, 0.5, 0.7]
        max_tokens_options = [100, 150, 200]
        
        best_config = None
        best_score = 0
        
        for temp in temperature_options:
            for tokens in max_tokens_options:
                # 临时更新配置
                original_temp = self.config.temperature
                original_tokens = self.config.max_tokens
                
                self.config.temperature = temp
                self.config.max_tokens = tokens
                
                # 测试配置
                total_confidence = 0
                for question in test_questions[:3]:  # 只测试前3个问题
                    response = self.generate_background(question)
                    total_confidence += response.confidence_score
                
                avg_confidence = total_confidence / min(3, len(test_questions))
                
                logger.info(f"Temp: {temp}, Tokens: {tokens}, Avg Confidence: {avg_confidence:.3f}")
                
                if avg_confidence > best_score:
                    best_score = avg_confidence
                    best_config = {"temperature": temp, "max_tokens": tokens}
                
                # 恢复原始配置
                self.config.temperature = original_temp
                self.config.max_tokens = original_tokens
        
        logger.info(f"Best configuration: {best_config} with score: {best_score:.3f}")
        return best_config or {"temperature": 0.5, "max_tokens": 150}
    
    def get_cache_stats(self) -> Dict[str, int]:
        """获取缓存统计信息"""
        cache_files = list(self.cache_dir.glob("*.pkl"))
        total_size = sum(f.stat().st_size for f in cache_files)
        
        return {
            "total_cached_items": len(cache_files),
            "total_cache_size_bytes": total_size,
            "total_cache_size_mb": total_size / (1024 * 1024)
        }
    
    def clear_cache(self):
        """清空缓存"""
        cache_files = list(self.cache_dir.glob("*.pkl"))
        for cache_file in cache_files:
            cache_file.unlink()
        logger.info(f"Cleared {len(cache_files)} cached items")
    
    def export_backgrounds(self, output_file: str):
        """导出所有背景知识到JSON文件"""
        cache_files = list(self.cache_dir.glob("*.pkl"))
        backgrounds = []
        
        for cache_file in cache_files:
            try:
                with open(cache_file, 'rb') as f:
                    response = pickle.load(f)
                    backgrounds.append({
                        "question": response.question,
                        "background": response.background_text,
                        "confidence": response.confidence_score,
                        "generated_at": response.generated_at.isoformat(),
                        "model": response.model_used,
                        "tokens": response.tokens_used
                    })
            except Exception as e:
                logger.warning(f"Failed to load {cache_file}: {e}")
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(backgrounds, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Exported {len(backgrounds)} backgrounds to {output_file}")


# 使用示例和测试代码
def main():
    """主函数 - 演示Ask LLM Background Enhancer的使用"""
    
    # 配置
    config = AskLLMConfig(
        model="gemini-pro",
        temperature=0.5,
        max_tokens=150,
        cache_enabled=True
    )
    
    # 初始化
    enhancer = AskLLMBackgroundEnhancer(config)
    
    # 测试问题
    test_questions = [
        "What is the role of CD33 in acute myeloid leukemia?",
        "How does CRISPR-Cas9 gene editing work?",
        "What are the mechanisms of drug resistance in cancer cells?",
        "How do neural networks learn from data?"
    ]
    
    print("=== Ask LLM Background Enhancer Demo (Gemini) ===\n")
    
    # 单个问题测试
    print("1. Single Question Test:")
    question = test_questions[0]
    response = enhancer.generate_background(question)
    
    print(f"Question: {question}")
    print(f"Background: {response.background_text}")
    print(f"Confidence: {response.confidence_score:.2f}")
    print(f"Tokens Used: {response.tokens_used}")
    print()
    
    # 批量处理测试
    print("2. Batch Processing Test:")
    responses = enhancer.batch_generate_background(test_questions[:2])
    
    for i, response in enumerate(responses):
        print(f"Question {i+1}: {response.question[:50]}...")
        print(f"Confidence: {response.confidence_score:.2f}")
        print()
    
    # 缓存统计
    print("3. Cache Statistics:")
    stats = enhancer.get_cache_stats()
    print(f"Cached Items: {stats['total_cached_items']}")
    print(f"Cache Size: {stats['total_cache_size_mb']:.2f} MB")
    print()
    
    # 参数优化
    print("4. Parameter Optimization:")
    best_params = enhancer.optimize_parameters(test_questions)
    print(f"Best Parameters: {best_params}")


if __name__ == "__main__":
    main()
