"""
PaperQA — Gather Evidence Tool
Implements: MMR retrieval + Summary LLM + LLM-based scoring (1–10 relevance)
"""
#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
import sys
import os
import json
import random
import asyncio
os.environ["OPENAI_API_KEY"] = "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"
# 解决 ThreadPoolExecutor 与 tokenizers 并行处理的警告
os.environ["TOKENIZERS_PARALLELISM"] = "false"
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import List, Optional
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from openai import OpenAI
from sentence_transformers import SentenceTransformer

from paperqa.schemas import Chunk, Evidence
from settings import Settings as RootSettings

# defaults/fallbacks from root Settings
EVIDENCE_TOPK_CONTEXT = getattr(RootSettings, "DEFAULT_TOP_CHUNK_NUM", 8)
EMBEDDING_MODEL = getattr(RootSettings, "EMBEDDING_MODEL", "BAAI/bge-base-en")
SUMMARY_LLM = getattr(RootSettings, "SUMMARY_LLM", "gpt-3.5-turbo")
MMR_LAMBDA = getattr(RootSettings, "DEFAULT_LAMBDA_MULT", 0.7)
# ----------------------------------------------------
# Retriever: use MMR to select diverse & relevant chunks
# ----------------------------------------------------
class Retriever:
    def __init__(self, chunks: List[Chunk], lambda_param: float = MMR_LAMBDA, embedder: Optional[SentenceTransformer] = None):
        self.chunks = chunks
        self.lambda_param = lambda_param
        self.embedder = embedder
        
    def _ensure_embeddings(self):
        """Generate embeddings for chunks that don't have them."""
        if self.embedder is None:
            self.embedder = SentenceTransformer("BAAI/bge-base-en")
        
        chunks_needing_embedding = [c for c in self.chunks if c.embedding is None]
        if chunks_needing_embedding:
            texts = [c.text for c in chunks_needing_embedding]
            embeddings = self.embedder.encode(texts, convert_to_numpy=True)
            for chunk, emb in zip(chunks_needing_embedding, embeddings):
                chunk.embedding = emb.tolist()

    def mmr_search(self, query_emb: np.ndarray, k: int = EVIDENCE_TOPK_CONTEXT) -> List[Chunk]:
        """Return top-k diverse and relevant chunks using Maximal Marginal Relevance (MMR)."""
        # Ensure all chunks have embeddings
        if not self.chunks:
            return []

        self._ensure_embeddings()
        
        # Flatten query_emb if it's 2D
        if len(query_emb.shape) > 1:
            query_emb = query_emb.flatten()
        
        # Filter out chunks that still lack embeddings for any reason
        valid_chunks = [c for c in self.chunks if isinstance(c.embedding, (list, tuple))]
        if not valid_chunks:
            return []

        docs = np.stack([np.array(c.embedding) for c in valid_chunks])
        selected, remaining = [], list(range(len(docs)))

        sim_to_query = np.dot(docs, query_emb) / (
            np.linalg.norm(docs, axis=1) * np.linalg.norm(query_emb)
        )
        sim_matrix = np.dot(docs, docs.T)

        k = max(1, int(k))
        while len(selected) < k and remaining:
            mmr_scores = []
            for i in remaining:
                redundancy = max([sim_matrix[i, j] for j in selected], default=0)
                score = self.lambda_param * sim_to_query[i] - (1 - self.lambda_param) * redundancy
                mmr_scores.append(score)
            next_idx = remaining[np.argmax(mmr_scores)]
            selected.append(next_idx)
            remaining.remove(next_idx)

        return [valid_chunks[i] for i in selected]


# ----------------------------------------------------
# Summarizer: LLM summarization + LLM relevance scoring
# ----------------------------------------------------
class Summarizer:
    def __init__(self, summary_model: str = "gpt-3.5-turbo", score_model: str = "gpt-4"):
        self.client = OpenAI()
        self.summary_model = summary_model  # GPT-3.5 for summarization
        self.score_model = score_model      # GPT-4 for scoring

    def summarize_and_score(self, chunk: Chunk, question: str) -> Evidence:
        """
        Use unified prompt to get both summary and score in one response.
        Uses GPT-4 for combined summary and scoring.
        """
        prompt = f"""Summarize the text below to help answer a question. Do not directly answer the question,
instead summarize to give evidence to help answer the question. Reply 'Not applicable' if
text is irrelevant. Use concise summary length. At the end of your response, provide a score from
1-10 on a newline indicating relevance to question. Do not explain your score.

Excerpt from citation:
{chunk.text}

Question: {question}

Relevant Information Summary:
"""

        response = self.client.chat.completions.create(
            model=self.score_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )

        content = response.choices[0].message.content.strip()
        
        # Parse summary and score from response
        if "\n" in content:
            *summary_lines, last_line = content.split("\n")
            summary = "\n".join(summary_lines).strip()
            # Extract score from last line
            import re
            match = re.search(r"(\d+(\.\d+)?)", last_line)
            score = float(match.group(1)) if match else None
        else:
            summary = content
            score = None

        return Evidence(chunk_id=chunk.chunk_id, summary=summary, score=score)


# ----------------------------------------------------
# GatherTool: orchestrates retrieval → summarize → score
# ----------------------------------------------------
class GatherTool:
    def __init__(self, retriever: Retriever, summarizer: Summarizer, embedder: Optional[SentenceTransformer] = None):
        self.retriever = retriever
        self.summarizer = summarizer
        self.embedder = embedder
        if self.embedder is None:
            self.embedder = SentenceTransformer("BAAI/bge-base-en")
        # Ensure retriever also has the embedder
        if self.retriever.embedder is None:
            self.retriever.embedder = self.embedder

    def gather(self, question: str, query_emb: Optional[np.ndarray] = None) -> List[Evidence]:
        """
        1️⃣ Retrieve diverse chunks (MMR)
        2️⃣ Summarize each chunk with LLM (1–10 scoring)
        3️⃣ Sort by score
        
        Args:
            question: The question to answer
            query_emb: Optional pre-computed query embedding. If None, will generate from question.
        """
        # Generate query embedding if not provided
        if query_emb is None:
            query_emb = self.embedder.encode([question], convert_to_numpy=True)[0]
        
        # Step 1 — MMR retrieval
        chunks: List[Chunk] = self.retriever.mmr_search(query_emb, k=EVIDENCE_TOPK_CONTEXT)
 
        # Step 2 — Concurrent summarization + scoring
        evidences: List[Evidence] = self._batch_summarize(chunks, question)

        # Step 3 — Sort by score (filter out None scores first)
        evidences = [e for e in evidences if e.score is not None]
        evidences.sort(key=lambda e: e.score, reverse=True)
        return evidences

    def _batch_summarize(self, chunks: List[Chunk], question: str) -> List[Evidence]:
        """Run summarization + scoring concurrently."""
        evidences = []
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(self.summarizer.summarize_and_score, c, question) for c in chunks]
            for f in futures:
                evidences.append(f.result())
        return evidences


if __name__ == "__main__":
    
    
    

    async def test_gather_evidence():
        try:
            litqa_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "litqa-v0.jsonl")
            with open(litqa_path, "r") as f:
                samples = [json.loads(line) for line in f if line.strip()]
            random.seed(123)
            sample = random.choice(samples)
            question = sample["question"]
            
            print(f"\n🧪 Testing LitQA Question:\n{question}\n")
            
            search_tool = SearchTool(None, None, None, None, None, None, None)
            hits = await search_tool.smart_search(question, min_hits=3, max_rounds=2)
            print(f"📚 Found {len(hits)} papers")
            
            chunks = await search_tool.ingest(hits)
            print(f"📄 Generated {len(chunks)} chunks\n")
            
            if not chunks:
                print("⚠️ No chunks available")
                return
            
            retriever = Retriever(chunks, embedder=search_tool.embedder)
            summarizer = Summarizer(summary_model="gpt-3.5-turbo", score_model="gpt-4")
            gather_tool = GatherTool(retriever, summarizer, embedder=search_tool.embedder)
            
            print("🔍 Gathering evidence...\n")
            evidences = gather_tool.gather(question)
            
            print(f"✅ Collected {len(evidences)} evidences:\n")
            for i, ev in enumerate(evidences[:10], 1):
                print(f"[{i}] Score: {ev.score}/10")
                print(f"    Chunk: {ev.chunk_id[:60]}...")
                print(f"    Summary: {ev.summary[:200]}...")
                
                print()
                
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()

    asyncio.run(test_gather_evidence())


# ---- Functional wrapper for pipeline integration ----
def run_tool(input_dict):
    """Gather evidence given search_result and background.

    Input dict:
      {"question": str,
       "search_result": {"chunks": [Chunk as dict...]},
       "background": {...}}
    Output dict:
      {"evidence": [Evidence as dict ...]}
    """
    from paperqa.schemas import Chunk as CK, Evidence as EV

    question = input_dict.get("question", "")
    search_result = input_dict.get("search_result", {})
    chunk_dicts = search_result.get("chunks", [])

    # Rebuild Chunk objects
    chunks = [CK(**c) for c in chunk_dicts]

    # Build retriever/summarizer
    retriever = Retriever(chunks)
    summarizer = Summarizer(summary_model=SUMMARY_LLM, score_model="gpt-4")
    tool = GatherTool(retriever, summarizer)

    evidences = tool.gather(question)

    def _asdict_ev(e: EV):
        return {
            "chunk_id": e.chunk_id,
            "summary": e.summary,
            "score": e.score,
        }

    return {"evidence": [_asdict_ev(e) for e in evidences]}
